// background_v2.js - Enhanced Background Script for Gnosis Wraith
// Version 1.4.0 - Terminal Mode Update

class GnosisWraithBackground {
  constructor() {
    this.apiSettings = {
      serverUrl: 'http://localhost:5678',
      captureOptions: {
        includeScreenshot: true,
        processingMode: 'enhanced'
      }
    };
    
    this.fullPageCaptureState = {
      inProgress: false,
      dimensions: null,
      screenshots: [],
      tabId: null,
      sendToApi: false,
      options: {}
    };
    
    this.init();
  }
  
  async init() {
    await this.loadSettings();
    this.setupMessageListeners();
    this.setupContextMenus();
    console.log('Gnosis Wraith Background v1.4.0 initialized');
  }
  
  async loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['serverUrl', 'captureOptions'], (result) => {
        if (result.serverUrl) {
          this.apiSettings.serverUrl = result.serverUrl;
        }
        if (result.captureOptions) {
          this.apiSettings.captureOptions = {
            ...this.apiSettings.captureOptions,
            ...result.captureOptions
          };
        }
        resolve();
      });
    });
  }
  
  setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      // Handle async responses
      const handleAsync = async () => {
        try {
          const response = await this.handleMessage(message, sender);
          sendResponse(response);
        } catch (error) {
          sendResponse({
            success: false,
            error: error.message || 'Unknown error'
          });
        }
      };
      
      handleAsync();
      return true; // Keep channel open for async response
    });
  }
  
  async handleMessage(message, sender) {
    switch (message.action) {
      case 'updateServerUrl':
        this.apiSettings.serverUrl = message.serverUrl;
        return { success: true };
        
      case 'captureCurrentPage':
        return await this.handleCaptureRequest(message);
        
      case 'captureVisibleArea':
        return await this.captureVisibleArea(message);
        
      case 'beginFullPageCapture':
        return this.beginFullPageCapture(message, sender);
        
      case 'finishFullPageCapture':
        return await this.finishFullPageCapture(message);
        
      case 'fullPageCaptureFailed':
        return this.handleFullPageFailure(message);
        
      default:
        throw new Error(`Unknown action: ${message.action}`);
    }
  }
  
  async handleCaptureRequest(message) {
    const { tabId, options } = message;
    
    if (!tabId) {
      throw new Error('No tab ID provided');
    }
    
    // Notify content script that capture is starting
    try {
      await chrome.tabs.sendMessage(tabId, {
        action: 'capturingStarted'
      });
    } catch (error) {
      console.warn('Could not notify content script:', error);
    }
    
    if (options.fullPage) {
      // Initiate full page capture through content script
      await chrome.tabs.sendMessage(tabId, {
        action: 'requestFullPageCapture',
        sendToApi: options.sendToApi
      });
      
      return {
        success: true,
        status: 'fullPageInitiated'
      };
    } else {
      // Regular screenshot
      const screenshotData = await this.takeScreenshot();
      
      if (options.sendToApi) {
        // Send to API
        const response = await this.sendToServer({
          screenshot: screenshotData,
          url: options.url,
          title: options.title,
          ...options
        });
        
        // Notify content script of result
        await chrome.tabs.sendMessage(tabId, {
          action: response.success ? 'uploadFinished' : 'uploadError',
          reportUrl: response.reportUrl,
          extractedText: response.extractedText,
          error: response.error
        });
        
        return response;
      } else {
        // Save locally
        await this.downloadScreenshot(screenshotData, options.title);
        
        // Notify content script
        await chrome.tabs.sendMessage(tabId, {
          action: 'capturingFinished',
          sendToApi: false
        });
        
        return {
          success: true,
          status: 'saved'
        };
      }
    }
  }
  
  async takeScreenshot() {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(null, {
        format: 'png'
      });
      return dataUrl;
    } catch (error) {
      console.error('Screenshot failed:', error);
      throw new Error('Failed to capture screenshot');
    }
  }
  
  async captureVisibleArea(message) {
    if (!this.fullPageCaptureState.inProgress) {
      throw new Error('No full page capture in progress');
    }
    
    const dataUrl = await this.takeScreenshot();
    
    if (dataUrl) {
      this.fullPageCaptureState.screenshots.push({
        dataUrl,
        position: message.position
      });
      
      return {
        success: true,
        dataUrl
      };
    } else {
      throw new Error('Failed to capture screenshot');
    }
  }
  
  beginFullPageCapture(message, sender) {
    this.fullPageCaptureState = {
      inProgress: true,
      dimensions: message.dimensions,
      screenshots: [],
      tabId: sender.tab?.id,
      sendToApi: message.sendToApi,
      url: message.url,
      title: message.title,
      options: message
    };
    
    console.log('Beginning full page capture:', message.dimensions);
    return { success: true };
  }
  
  async finishFullPageCapture(message) {
    if (!this.fullPageCaptureState.inProgress) {
      throw new Error('No full page capture in progress');
    }
    
    console.log(`Finishing capture with ${this.fullPageCaptureState.screenshots.length} screenshots`);
    
    try {
      // Stitch screenshots
      const stitchedDataUrl = await this.stitchFullPageScreenshot();
      
      this.fullPageCaptureState.inProgress = false;
      
      if (this.fullPageCaptureState.sendToApi) {
        // Send to server
        const response = await this.sendToServer({
          screenshot: stitchedDataUrl,
          url: this.fullPageCaptureState.url,
          title: this.fullPageCaptureState.title,
          fullPage: true,
          ...this.fullPageCaptureState.options
        });
        
        return {
          success: true,
          dataUrl: stitchedDataUrl,
          serverResponse: response
        };
      } else {
        // Save locally
        await this.downloadScreenshot(
          stitchedDataUrl,
          this.fullPageCaptureState.title,
          '_fullpage'
        );
        
        return {
          success: true,
          dataUrl: stitchedDataUrl
        };
      }
    } catch (error) {
      this.fullPageCaptureState.inProgress = false;
      throw error;
    }
  }
  
  handleFullPageFailure(message) {
    console.error('Full page capture failed:', message.error);
    this.fullPageCaptureState.inProgress = false;
    this.fullPageCaptureState.screenshots = [];
    return { acknowledged: true };
  }
  
  async stitchFullPageScreenshot() {
    const state = this.fullPageCaptureState;
    
    if (!state.dimensions || state.screenshots.length === 0) {
      throw new Error('Missing capture data for stitching');
    }
    
    const {
      fullWidth,
      fullHeight,
      viewportWidth,
      viewportHeight,
      numCols,
      numRows
    } = state.dimensions;
    
    console.log(`Stitching ${fullWidth}x${fullHeight} from ${state.screenshots.length} screenshots`);
    
    // Create canvas
    let canvas;
    let ctx;
    
    try {
      canvas = new OffscreenCanvas(fullWidth, fullHeight);
      ctx = canvas.getContext('2d');
    } catch (e) {
      console.log('Using regular canvas');
      canvas = document.createElement('canvas');
      canvas.width = fullWidth;
      canvas.height = fullHeight;
      ctx = canvas.getContext('2d');
    }
    
    // White background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, fullWidth, fullHeight);
    
    // Sort screenshots
    const sorted = [...state.screenshots].sort((a, b) => {
      if (a.position.row !== b.position.row) {
        return a.position.row - b.position.row;
      }
      return a.position.col - b.position.col;
    });
    
    // Draw screenshots
    let successCount = 0;
    for (const screenshot of sorted) {
      try {
        const imgBlob = await (await fetch(screenshot.dataUrl)).blob();
        const img = await createImageBitmap(imgBlob);
        
        const x = screenshot.position.col * viewportWidth;
        const y = screenshot.position.row * viewportHeight;
        
        ctx.drawImage(img, x, y);
        successCount++;
      } catch (error) {
        console.error(`Failed to draw screenshot at ${screenshot.position.row},${screenshot.position.col}:`, error);
      }
    }
    
    if (successCount === 0) {
      throw new Error('Failed to process any screenshots');
    }
    
    // Convert to data URL
    let dataUrl;
    if (canvas instanceof OffscreenCanvas) {
      const blob = await canvas.convertToBlob({ type: 'image/png' });
      dataUrl = await this.blobToDataUrl(blob);
    } else {
      dataUrl = canvas.toDataURL('image/png');
    }
    
    return dataUrl;
  }
  
  async blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
  
  async sendToServer(data) {
    try {
      // Format server URL
      let serverUrl = this.apiSettings.serverUrl;
      if (!serverUrl.startsWith('http://') && !serverUrl.startsWith('https://')) {
        serverUrl = 'http://' + serverUrl;
      }
      serverUrl = serverUrl.replace(/\/$/, '');
      
      // Use the new crawl endpoint with minimal response format
      const endpoint = '/api/crawl';
      
      console.log(`Sending to ${serverUrl}${endpoint}`, {
        url: data.url,
        title: data.title,
        hasScreenshot: !!data.screenshot,
        options: data
      });
      
      // Prepare request body
      const requestBody = {
        url: data.url,
        title: data.custom_title || data.title,
        take_screenshot: !!data.screenshot,
        screenshot_data: data.screenshot, // Include the actual screenshot data
        javascript_enabled: true,
        markdown_extraction: data.markdown_extraction || 'enhanced',
        ocr_extraction: data.ocr_extraction || false,
        response_format: 'minimal'
      };
      
      const response = await fetch(`${serverUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }
      
      const result = await response.json();
      
      // Format response
      return {
        success: result.success,
        reportUrl: result.report_url || `${serverUrl}/reports`,
        extractedText: result.markdown_content || result.extracted_text,
        error: result.error
      };
      
    } catch (error) {
      console.error('Server communication error:', error);
      return {
        success: false,
        error: error.message || 'Failed to communicate with server'
      };
    }
  }
  
  async downloadScreenshot(dataUrl, title, suffix = '') {
    const filename = this.sanitizeFilename(title || 'screenshot') + suffix + '.png';
    
    try {
      await chrome.downloads.download({
        url: dataUrl,
        filename: filename,
        saveAs: true
      });
    } catch (error) {
      console.error('Download failed:', error);
      throw new Error('Failed to save screenshot');
    }
  }
  
  sanitizeFilename(filename) {
    return filename
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, '_')
      .substring(0, 100);
  }
  
  setupContextMenus() {
    // Remove existing menus
    chrome.contextMenus.removeAll(() => {
      // Create new context menus
      chrome.contextMenus.create({
        id: 'gnosis-capture',
        title: 'Capture with Gnosis Wraith',
        contexts: ['page']
      });
      
      chrome.contextMenus.create({
        id: 'gnosis-capture-analyze',
        parentId: 'gnosis-capture',
        title: '🔍 Capture & Analyze',
        contexts: ['page']
      });
      
      chrome.contextMenus.create({
        id: 'gnosis-capture-screenshot',
        parentId: 'gnosis-capture',
        title: '📷 Screenshot Only',
        contexts: ['page']
      });
      
      chrome.contextMenus.create({
        id: 'gnosis-capture-fullpage',
        parentId: 'gnosis-capture',
        title: '📜 Full Page Capture',
        contexts: ['page']
      });
      
      chrome.contextMenus.create({
        id: 'gnosis-capture-extract',
        parentId: 'gnosis-capture',
        title: '📝 Extract Text (with OCR)',
        contexts: ['page']
      });
    });
    
    // Handle context menu clicks
    chrome.contextMenus.onClicked.addListener((info, tab) => {
      const options = {
        url: tab.url,
        title: tab.title,
        sendToApi: true,
        fullPage: false,
        ocr_extraction: false,
        markdown_extraction: 'enhanced',
        response_format: 'minimal'
      };
      
      switch (info.menuItemId) {
        case 'gnosis-capture-screenshot':
          options.sendToApi = false;
          break;
          
        case 'gnosis-capture-fullpage':
          options.fullPage = true;
          break;
          
        case 'gnosis-capture-extract':
          options.ocr_extraction = true;
          break;
      }
      
      // Send capture request
      this.handleCaptureRequest({
        tabId: tab.id,
        options
      });
    });
  }
}

// Initialize background service
const gnosisWraith = new GnosisWraithBackground();