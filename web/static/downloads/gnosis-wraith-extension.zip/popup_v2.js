// popup_v2.js - Enhanced Gnosis Wraith Extension
// Version 1.4.0 - Terminal Mode Update

class GnosisWraithPopup {
  constructor() {
    this.state = {
      uploadEnabled: true,
      fullPageEnabled: false,
      ocrEnabled: false,
      markdownMode: 'enhanced',
      screenshotMode: 'top',
      serverUrl: 'http://localhost:5678',
      customServerUrl: '',
      reportName: '',
      isProcessing: false,
      serverConnected: false
    };
    
    this.init();
  }
  
  async init() {
    await this.loadSettings();
    this.bindElements();
    this.attachEventListeners();
    this.updateUI();
    this.checkServerConnection();
    
    // Check server connection every 5 seconds
    setInterval(() => this.checkServerConnection(), 5000);
  }
  
  bindElements() {
    // Quick action buttons
    this.quickScreenshot = document.getElementById('quick-screenshot');
    this.quickAnalyze = document.getElementById('quick-analyze');
    this.quickFullPage = document.getElementById('quick-full-page');
    this.quickExtract = document.getElementById('quick-extract');
    
    // Toggle switches
    this.uploadToggle = document.getElementById('upload-toggle');
    this.fullPageToggle = document.getElementById('fullpage-toggle');
    this.ocrToggle = document.getElementById('ocr-toggle');
    
    // Advanced options
    this.advancedToggleBtn = document.getElementById('advanced-toggle-btn');
    this.advancedOptions = document.getElementById('advanced-options');
    this.markdownMode = document.getElementById('markdown-mode');
    this.screenshotMode = document.getElementById('screenshot-mode');
    this.reportName = document.getElementById('report-name');
    
    // Server config
    this.serverSelect = document.getElementById('server-select');
    this.customServer = document.getElementById('custom-server');
    this.serverStatus = document.getElementById('server-status');
    
    // Main capture button
    this.captureBtn = document.getElementById('capture-btn');
    this.captureBtnText = document.getElementById('capture-btn-text');
    
    // Message area
    this.messageDiv = document.getElementById('message');
    
    // Footer links
    this.helpLink = document.getElementById('help-link');
    this.reportsLink = document.getElementById('reports-link');
    this.shortcutsLink = document.getElementById('shortcuts-link');
  }
  
  attachEventListeners() {
    // Quick actions
    this.quickScreenshot.addEventListener('click', () => this.quickCapture('screenshot'));
    this.quickAnalyze.addEventListener('click', () => this.quickCapture('analyze'));
    this.quickFullPage.addEventListener('click', () => this.quickCapture('fullpage'));
    this.quickExtract.addEventListener('click', () => this.quickCapture('extract'));
    
    // Toggle switches
    this.uploadToggle.addEventListener('click', () => this.toggleSwitch('uploadEnabled'));
    this.fullPageToggle.addEventListener('click', () => this.toggleSwitch('fullPageEnabled'));
    this.ocrToggle.addEventListener('click', () => this.toggleSwitch('ocrEnabled'));
    
    // Advanced options
    this.advancedToggleBtn.addEventListener('click', () => this.toggleAdvanced());
    this.markdownMode.addEventListener('change', () => this.updateSetting('markdownMode', this.markdownMode.value));
    this.screenshotMode.addEventListener('change', () => this.updateSetting('screenshotMode', this.screenshotMode.value));
    this.reportName.addEventListener('input', () => this.updateSetting('reportName', this.reportName.value));
    
    // Server config
    this.serverSelect.addEventListener('change', () => this.handleServerChange());
    this.customServer.addEventListener('input', () => this.updateSetting('customServerUrl', this.customServer.value));
    
    // Main capture button
    this.captureBtn.addEventListener('click', () => this.handleCapture());
    
    // Footer links
    this.helpLink.addEventListener('click', (e) => this.showHelp(e));
    this.reportsLink.addEventListener('click', (e) => this.openReports(e));
    this.shortcutsLink.addEventListener('click', (e) => this.showShortcuts(e));
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => this.handleKeyboard(e));
  }
  
  async loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get([
        'uploadEnabled',
        'fullPageEnabled',
        'ocrEnabled',
        'markdownMode',
        'screenshotMode',
        'serverUrl',
        'customServerUrl',
        'reportName'
      ], (result) => {
        // Merge with defaults
        this.state = { ...this.state, ...result };
        resolve();
      });
    });
  }
  
  async saveSettings() {
    await chrome.storage.local.set(this.state);
    
    // Notify background script of server URL change
    chrome.runtime.sendMessage({
      action: 'updateServerUrl',
      serverUrl: this.getActiveServerUrl()
    });
  }
  
  getActiveServerUrl() {
    if (this.state.serverUrl === 'custom' && this.state.customServerUrl) {
      return this.state.customServerUrl;
    }
    return this.state.serverUrl;
  }
  
  updateUI() {
    // Update toggle switches
    this.uploadToggle.classList.toggle('active', this.state.uploadEnabled);
    this.fullPageToggle.classList.toggle('active', this.state.fullPageEnabled);
    this.ocrToggle.classList.toggle('active', this.state.ocrEnabled);
    
    // Update select fields
    this.markdownMode.value = this.state.markdownMode;
    this.screenshotMode.value = this.state.screenshotMode;
    this.serverSelect.value = this.state.serverUrl;
    this.reportName.value = this.state.reportName || '';
    
    // Show/hide custom server input
    this.customServer.style.display = this.state.serverUrl === 'custom' ? 'block' : 'none';
    if (this.state.serverUrl === 'custom') {
      this.customServer.value = this.state.customServerUrl || '';
    }
    
    // Update capture button text
    this.updateCaptureButtonText();
  }
  
  updateCaptureButtonText() {
    if (this.state.isProcessing) {
      this.captureBtnText.innerHTML = '<span class="spinner"></span>PROCESSING...';
      this.captureBtn.disabled = true;
      return;
    }
    
    this.captureBtn.disabled = false;
    
    if (this.state.uploadEnabled) {
      if (this.state.fullPageEnabled) {
        this.captureBtnText.textContent = 'CAPTURE & ANALYZE FULL PAGE';
      } else {
        this.captureBtnText.textContent = 'CAPTURE & ANALYZE';
      }
    } else {
      if (this.state.fullPageEnabled) {
        this.captureBtnText.textContent = 'CAPTURE FULL PAGE';
      } else {
        this.captureBtnText.textContent = 'CAPTURE SCREENSHOT';
      }
    }
  }
  
  toggleSwitch(setting) {
    this.state[setting] = !this.state[setting];
    this.updateUI();
    this.saveSettings();
  }
  
  updateSetting(setting, value) {
    this.state[setting] = value;
    this.saveSettings();
  }
  
  toggleAdvanced() {
    const isShown = this.advancedOptions.classList.contains('show');
    this.advancedOptions.classList.toggle('show');
    this.advancedToggleBtn.textContent = isShown ? 'Advanced Options ▼' : 'Advanced Options ▲';
  }
  
  handleServerChange() {
    this.state.serverUrl = this.serverSelect.value;
    this.updateUI();
    this.saveSettings();
    this.checkServerConnection();
  }
  
  async checkServerConnection() {
    const serverUrl = this.getActiveServerUrl();
    
    try {
      const response = await fetch(`${serverUrl}/api/health`, {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache'
      });
      
      this.state.serverConnected = response.ok;
    } catch (error) {
      this.state.serverConnected = false;
    }
    
    this.serverStatus.classList.toggle('connected', this.state.serverConnected);
    this.serverStatus.title = this.state.serverConnected 
      ? 'Server connected' 
      : 'Server disconnected';
  }
  
  async quickCapture(mode) {
    switch (mode) {
      case 'screenshot':
        // Quick screenshot without upload
        this.state.uploadEnabled = false;
        this.state.fullPageEnabled = false;
        break;
        
      case 'analyze':
        // Screenshot with analysis
        this.state.uploadEnabled = true;
        this.state.fullPageEnabled = false;
        break;
        
      case 'fullpage':
        // Full page capture
        this.state.uploadEnabled = true;
        this.state.fullPageEnabled = true;
        break;
        
      case 'extract':
        // Text extraction focus
        this.state.uploadEnabled = true;
        this.state.fullPageEnabled = false;
        this.state.ocrEnabled = true;
        break;
    }
    
    this.updateUI();
    await this.saveSettings();
    this.handleCapture();
  }
  
  async handleCapture() {
    if (this.state.isProcessing) return;
    
    this.state.isProcessing = true;
    this.updateCaptureButtonText();
    
    try {
      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.url) {
        throw new Error('Cannot access current tab');
      }
      
      // Check for restricted URLs
      if (this.isRestrictedUrl(tab.url)) {
        throw new Error('Cannot capture browser internal pages');
      }
      
      // Show initial message
      this.showMessage('Preparing capture...', 'info');
      
      // Prepare capture options
      const captureOptions = {
        url: tab.url,
        title: tab.title,
        fullPage: this.state.fullPageEnabled,
        sendToApi: this.state.uploadEnabled,
        ocr_extraction: this.state.ocrEnabled,
        markdown_extraction: this.state.markdownMode,
        screenshot_mode: this.state.screenshotMode,
        custom_title: this.state.reportName || null,
        response_format: 'minimal' // Use minimal format for extension
      };
      
      // Send capture request
      chrome.runtime.sendMessage({
        action: 'captureCurrentPage',
        tabId: tab.id,
        options: captureOptions
      }, (response) => {
        if (chrome.runtime.lastError) {
          this.handleError(chrome.runtime.lastError.message);
          return;
        }
        
        if (response && response.success) {
          this.handleCaptureSuccess(response);
        } else {
          this.handleError(response?.error || 'Capture failed');
        }
      });
      
      // Close popup after initiating capture
      setTimeout(() => window.close(), 1000);
      
    } catch (error) {
      this.handleError(error.message);
    }
  }
  
  isRestrictedUrl(url) {
    const restricted = [
      'chrome://',
      'chrome-extension://',
      'edge://',
      'about:',
      'brave://',
      'opera://',
      'vivaldi://',
      'chrome-search://'
    ];
    
    return restricted.some(prefix => url.startsWith(prefix));
  }
  
  handleCaptureSuccess(response) {
    this.state.isProcessing = false;
    this.updateCaptureButtonText();
    
    const message = this.state.uploadEnabled 
      ? 'Page sent for analysis!' 
      : 'Screenshot captured!';
      
    this.showMessage(message, 'success');
  }
  
  handleError(error) {
    this.state.isProcessing = false;
    this.updateCaptureButtonText();
    this.showMessage(`Error: ${error}`, 'error');
  }
  
  showMessage(text, type = 'info') {
    this.messageDiv.textContent = text;
    this.messageDiv.className = `message ${type}`;
    this.messageDiv.style.display = 'block';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      this.messageDiv.style.display = 'none';
    }, 5000);
  }
  
  handleKeyboard(e) {
    // Quick capture shortcuts
    if (e.altKey && e.shiftKey) {
      switch (e.key.toUpperCase()) {
        case 'W':
          e.preventDefault();
          this.quickCapture('screenshot');
          break;
        case 'A':
          e.preventDefault();
          this.quickCapture('analyze');
          break;
        case 'F':
          e.preventDefault();
          this.quickCapture('fullpage');
          break;
        case 'T':
          e.preventDefault();
          this.quickCapture('extract');
          break;
      }
    }
  }
  
  showHelp(e) {
    e.preventDefault();
    this.showMessage(
      'Gnosis Wraith captures and analyzes web pages. Use quick actions or configure advanced options for detailed control.',
      'info'
    );
  }
  
  openReports(e) {
    e.preventDefault();
    const serverUrl = this.getActiveServerUrl();
    chrome.tabs.create({ url: `${serverUrl}/reports` });
  }
  
  showShortcuts(e) {
    e.preventDefault();
    
    // Create shortcuts modal
    const modal = document.createElement('div');
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.9);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    `;
    
    modal.innerHTML = `
      <div style="background: var(--bg-medium); border: 1px solid var(--border-color); 
                  border-radius: 8px; padding: 20px; max-width: 300px; color: var(--text-primary);">
        <h3 style="margin-bottom: 15px; text-align: center;">Keyboard Shortcuts</h3>
        <div style="font-size: 12px; line-height: 1.8;">
          <div><span class="kbd">Alt</span> + <span class="kbd">Shift</span> + <span class="kbd">W</span> - Screenshot</div>
          <div><span class="kbd">Alt</span> + <span class="kbd">Shift</span> + <span class="kbd">A</span> - Analyze</div>
          <div><span class="kbd">Alt</span> + <span class="kbd">Shift</span> + <span class="kbd">F</span> - Full Page</div>
          <div><span class="kbd">Alt</span> + <span class="kbd">Shift</span> + <span class="kbd">T</span> - Extract Text</div>
        </div>
        <button style="width: 100%; margin-top: 15px; padding: 8px; background: var(--primary-dark); 
                       border: none; color: var(--bg-dark); border-radius: 4px; cursor: pointer;
                       font-weight: bold;">CLOSE</button>
      </div>
    `;
    
    modal.addEventListener('click', () => document.body.removeChild(modal));
    document.body.appendChild(modal);
  }
}

// Initialize popup when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new GnosisWraithPopup();
});